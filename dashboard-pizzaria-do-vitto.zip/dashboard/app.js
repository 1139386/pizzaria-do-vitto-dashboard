(function () {
'use strict';
const D = window.DATA;
const NO = D.od.length;
const MES = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
const DIAS = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];
const DIAS_L = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo'];
const nf = new Intl.NumberFormat('pt-BR');
const nf1 = new Intl.NumberFormat('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 });
const nf2 = new Intl.NumberFormat('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const $ = (s, r) => (r || document).querySelector(s);
const NS = 'http://www.w3.org/2000/svg';

// ---------- calendário
const base = Date.UTC(2025, 0, 1);
let maxDay = 0; for (let i = 0; i < NO; i++) if (D.od[i] > maxDay) maxDay = D.od[i];
const monthOf = new Int16Array(maxDay + 1), dowOf = new Int8Array(maxDay + 1);
for (let i = 0; i <= maxDay; i++) {
  const d = new Date(base + i * 864e5);
  monthOf[i] = (d.getUTCFullYear() - 2025) * 12 + d.getUTCMonth();
  dowOf[i] = (d.getUTCDay() + 6) % 7;
}
const NM = monthOf[maxDay] + 1;
const mLabel = m => MES[m % 12] + '/' + String(25 + Math.floor(m / 12)).slice(-2);
const mDay = m => Math.round((Date.UTC(2025 + Math.floor(m / 12), m % 12, 1) - base) / 864e5);
const SKN = D.sku.map(s => s[0]), SKT = D.sku.map(s => s[1]), SKC = D.sku.map(s => s[2]);

// ---------- estado e filtros
const PERIODOS = [
  { k: 'all', t: 'Tudo', from: 0, to: maxDay },
  { k: '25', t: '2025', from: 0, to: mDay(12) - 1 },
  { k: '26', t: '2026', from: mDay(12), to: maxDay },
  { k: 'u3', t: 'Últimos 3 meses', from: mDay(NM - 3), to: maxDay }
];
const METRICAS = [{ k: 'rev', t: 'Faturamento' }, { k: 'ord', t: 'Pedidos' }, { k: 'piz', t: 'Pizzas' }];
const st = { per: 0, cat: -1, tam: -1, met: 'rev' };
const opts = {
  per: PERIODOS.map((p, i) => [i, p.t]),
  cat: [[-1, 'Todas']].concat(D.cat.map((c, i) => [i, c])),
  tam: [[-1, 'Todos']].concat(D.tam.map((c, i) => [i, c])),
  met: METRICAS.map(m => [m.k, m.t])
};
function buildChips(key) {
  const box = $('#f-' + { per: 'per', cat: 'cat', tam: 'tam', met: 'met' }[key] + ' .chips');
  box.innerHTML = '';
  opts[key].forEach(([val, txt]) => {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'chip'; b.textContent = txt; b.setAttribute('role', 'radio');
    b.setAttribute('aria-checked', String(st[key] === val));
    b.addEventListener('click', () => { st[key] = val; syncChips(); update(); });
    box.appendChild(b);
  });
}
function syncChips() {
  ['per', 'cat', 'tam', 'met'].forEach(key => {
    const bs = document.querySelectorAll('#f-' + key + ' .chip');
    opts[key].forEach(([val], i) => bs[i].setAttribute('aria-checked', String(st[key] === val)));
  });
}

// ---------- cálculo
function compute() {
  const per = PERIODOS[st.per];
  const mRev = new Float64Array(NM), mOrd = new Int32Array(NM), mPiz = new Int32Array(NM), mDias = new Int32Array(NM);
  const seenAll = new Uint8Array(maxDay + 1), seenSel = new Uint8Array(maxDay + 1);
  const dow = Array.from({ length: 7 }, () => ({ rev: 0, ord: 0, piz: 0, dias: 0 }));
  const hr = Array.from({ length: 24 }, () => ({ rev: 0, ord: 0, piz: 0 }));
  const sk = SKN.map(() => ({ rev: 0, ord: 0, piz: 0 }));
  const T = { rev: 0, ord: 0, piz: 0, dias: 0 };
  const tickets = [];
  let p = 0;
  for (let o = 0; o < NO; o++) {
    const n = D.on[o], d = D.od[o], inP = d >= per.from && d <= per.to;
    let orev = 0, opiz = 0, any = false;
    for (let k = p; k < p + n; k++) {
      const s = D.ls[k];
      if ((st.cat >= 0 && SKC[s] !== st.cat) || (st.tam >= 0 && SKT[s] !== st.tam)) continue;
      const v = D.lv[k], q = D.lq[k];
      orev += v; opiz += q; any = true;
      if (inP) { const e = sk[s]; e.rev += v; e.piz += q; e.ord++; }
    }
    p += n;
    if (!any) continue;
    const m = monthOf[d];
    mRev[m] += orev; mOrd[m]++; mPiz[m] += opiz; seenAll[d] = 1;
    if (!inP) continue;
    seenSel[d] = 1;
    T.rev += orev; T.ord++; T.piz += opiz; tickets.push(orev);
    const w = dow[dowOf[d]]; w.rev += orev; w.ord++; w.piz += opiz;
    const h = hr[Math.max(D.oh[o], 10)]; h.rev += orev; h.ord++; h.piz += opiz;
  }
  for (let d = 0; d <= maxDay; d++) {
    if (seenAll[d]) mDias[monthOf[d]]++;
    if (seenSel[d]) { dow[dowOf[d]].dias++; T.dias++; }
  }
  const c = x => x / 100;
  const month = { rev: Array.from(mRev, c), ord: Array.from(mOrd), piz: Array.from(mPiz), dias: Array.from(mDias) };
  dow.forEach(w => w.rev = c(w.rev)); hr.forEach(h => h.rev = c(h.rev)); sk.forEach(s => s.rev = c(s.rev));
  T.rev = c(T.rev);
  tickets.sort((a, b) => a - b);
  T.med = tickets.length ? c(tickets[Math.floor(tickets.length / 2)]) : 0;
  return { month, dow, hr, sk, T, per };
}

// previsão: suavização exponencial simples (mesmo método do relatório)
function ses(y, h) {
  let best = 0.01, bestE = Infinity;
  for (let a = 0.01; a < 0.995; a += 0.01) {
    let l = y[0], e = 0;
    for (let t = 1; t < y.length; t++) { e += (y[t] - l) * (y[t] - l); l += a * (y[t] - l); }
    if (e < bestE) { bestE = e; best = a; }
  }
  const al = Math.round(best * 100) / 100;
  let l = y[0]; const res = [];
  for (let t = 1; t < y.length; t++) { res.push(y[t] - l); l += al * (y[t] - l); }
  const mu = res.reduce((a, b) => a + b, 0) / res.length;
  const s = Math.sqrt(res.reduce((a, b) => a + (b - mu) * (b - mu), 0) / (res.length - 1));
  const out = [];
  for (let k = 1; k <= h; k++) {
    const sd = s * Math.sqrt(1 + (k - 1) * al * al);
    out.push({ f: l, lo95: Math.max(0, l - 1.96 * sd), hi95: l + 1.96 * sd, lo80: Math.max(0, l - 1.2816 * sd), hi80: l + 1.2816 * sd });
  }
  return { al, out };
}

// ---------- formatação
function money(x, short) {
  if (x >= 1e6) return 'R$ ' + nf2.format(x / 1e6) + ' mi';
  if (x >= 1e4) return 'R$ ' + nf.format(Math.round(x / 100) / 10).replace(/,0$/, '') + ' mil';
  return 'R$ ' + nf.format(Math.round(x));
}
function fm(x, met) { return met === 'rev' ? money(x) : nf.format(Math.round(x)); }
function axisFmt(x, met) {
  if (met === 'rev') return x >= 1000 ? nf.format(Math.round(x / 100) / 10).replace(/,0$/, '') + ' mil' : nf.format(x);
  return nf.format(x);
}
function niceTicks(lo, hi, n) {
  const span = hi - lo || 1, raw = span / n, mag = Math.pow(10, Math.floor(Math.log10(raw)));
  const step = [1, 2, 2.5, 5, 10].map(m => m * mag).find(s => s >= raw);
  const a = Math.floor(lo / step) * step, b = Math.ceil(hi / step) * step, t = [];
  for (let v = a; v <= b + step / 2; v += step) t.push(v);
  return t;
}
const METN = { rev: 'Faturamento', ord: 'Pedidos', piz: 'Pizzas vendidas' };
const el = (tag, attrs, txt) => { const e = document.createElementNS(NS, tag); for (const k in attrs) e.setAttribute(k, attrs[k]); if (txt != null) e.textContent = txt; return e; };

// ---------- tooltip
const tip = $('#tip');
function showTip(html, x, y) {
  tip.innerHTML = html; tip.hidden = false;
  const w = tip.offsetWidth, h = tip.offsetHeight;
  let lx = x + 14, ly = y - h - 12;
  if (lx + w > innerWidth - 8) lx = x - w - 14;
  if (lx < 8) lx = 8;
  if (ly < 8) ly = y + 18;
  tip.style.left = lx + 'px'; tip.style.top = ly + 'px';
}
const hideTip = () => { tip.hidden = true; };

// ---------- KPIs
function sparkline(vals, color) {
  const w = 200, h = 34, mx = Math.max(...vals), mn = Math.min(...vals), r = mx - mn || 1;
  const pts = vals.map((v, i) => [i / (vals.length - 1) * (w - 4) + 2, h - 4 - (v - mn) / r * (h - 8)]);
  return `<svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" aria-hidden="true"><polyline fill="none" stroke="${color}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke" points="${pts.map(p => p.join(',')).join(' ')}"/></svg>`;
}
function renderKPIs(R) {
  const T = R.T, M = R.month, per = Math.max(T.dias, 1);
  const tk = M.rev.map((v, i) => M.ord[i] ? v / M.ord[i] : 0);
  const cards = [
    ['Faturamento', money(T.rev), money(T.rev / per) + ' por dia com vendas', M.rev],
    ['Pedidos', nf.format(T.ord), nf1.format(T.ord / per) + ' por dia com vendas', M.ord],
    ['Ticket médio', T.ord ? 'R$ ' + nf2.format(T.rev / T.ord) : '–', T.ord ? 'Metade dos pedidos fica abaixo de R$ ' + nf2.format(T.med) : '', tk],
    ['Pizzas vendidas', nf.format(T.piz), T.ord ? nf2.format(T.piz / T.ord) + ' por pedido' : '', M.piz]
  ];
  $('#kpis').innerHTML = cards.map(c => `<div class="card kpi"><div class="kl">${c[0]}</div><div class="kv">${c[1]}</div><div class="kn">${c[2]}</div>${sparkline(c[3], 'var(--bar)')}</div>`).join('');
}

// ---------- gráfico principal (linha + previsão)
let heroGeom = null;
function renderHero(R) {
  const met = st.met, host = $('#hero'), y = R.month[met];
  const F = ses(y, 3), per = R.per;
  const W = Math.max(host.clientWidth, 280), narrow = W < 560, H = narrow ? 270 : 340;
  const ml = narrow ? 42 : 52, mr = 14, mt = 12, mb = 30;
  const NP = NM + 3, step = (W - ml - mr) / NP, X = i => ml + (i + 0.5) * step;
  const all = y.concat(F.out.map(f => f.hi95)), lo = Math.min(...y, ...F.out.map(f => f.lo95)), hi = Math.max(...all);
  const pad = (hi - lo) * 0.08, ticks = niceTicks(Math.max(0, lo - pad), hi + pad, narrow ? 4 : 5);
  const y0 = ticks[0], y1 = ticks[ticks.length - 1], Y = v => mt + (1 - (v - y0) / (y1 - y0)) * (H - mt - mb);
  const svg = el('svg', { viewBox: `0 0 ${W} ${H}`, height: H, role: 'img', 'aria-label': `${METN[met]} por mês, de ${mLabel(0)} a ${mLabel(NM - 1)}, com previsão para os 3 meses seguintes.` });
  // período selecionado
  if (st.per !== 0) {
    const m0 = monthOf[per.from], m1 = monthOf[per.to];
    svg.appendChild(el('rect', { x: X(m0) - step / 2, y: mt, width: (m1 - m0 + 1) * step, height: H - mt - mb, fill: 'var(--sel)', rx: 6 }));
  }
  ticks.forEach(t => {
    svg.appendChild(el('line', { x1: ml, x2: W - mr, y1: Y(t), y2: Y(t), stroke: 'var(--grid)', 'stroke-width': 1 }));
    svg.appendChild(el('text', { x: ml - 8, y: Y(t) + 4, 'text-anchor': 'end', 'font-size': 12, fill: 'var(--mut)' }, axisFmt(t, met)));
  });
  const every = narrow ? 4 : 2;
  for (let i = 0; i < NP; i++) {
    const isF = i >= NM;
    if ((i % every === 0 && i < NM - 3) || i === NM - 1 || i === NM + 2) {
      if (true)
        svg.appendChild(el('text', { x: X(i), y: H - 8, 'text-anchor': 'middle', 'font-size': 12, fill: isF ? 'var(--acc)' : 'var(--mut)', 'font-weight': isF ? 600 : 400 }, mLabel(i)));
    }
  }
  // faixas
  const xs = [NM - 1, NM, NM + 1, NM + 2], last = y[NM - 1];
  const poly = (key1, key2) => {
    const up = xs.map((i, k) => [X(i), Y(k === 0 ? last : F.out[k - 1][key2])]);
    const dn = xs.map((i, k) => [X(i), Y(k === 0 ? last : F.out[k - 1][key1])]).reverse();
    return up.concat(dn).map(p => p.join(',')).join(' ');
  };
  svg.appendChild(el('polygon', { points: poly('lo95', 'hi95'), fill: 'var(--acc-band2)' }));
  svg.appendChild(el('polygon', { points: poly('lo80', 'hi80'), fill: 'var(--acc-band)' }));
  // série real
  svg.appendChild(el('polyline', { points: y.map((v, i) => X(i) + ',' + Y(v)).join(' '), fill: 'none', stroke: 'var(--bar)', 'stroke-width': 2.5, 'stroke-linejoin': 'round' }));
  y.forEach((v, i) => svg.appendChild(el('circle', { cx: X(i), cy: Y(v), r: 3.5, fill: 'var(--bar)', stroke: 'var(--card)', 'stroke-width': 1.5 })));
  // previsão
  svg.appendChild(el('polyline', { points: xs.map((i, k) => X(i) + ',' + Y(k === 0 ? last : F.out[k - 1].f)).join(' '), fill: 'none', stroke: 'var(--acc)', 'stroke-width': 2.5, 'stroke-dasharray': '6 5' }));
  F.out.forEach((f, k) => svg.appendChild(el('circle', { cx: X(NM + k), cy: Y(f.f), r: 4.5, fill: 'var(--acc)', stroke: 'var(--card)', 'stroke-width': 1.5 })));
  // hover
  const vl = el('line', { y1: mt, y2: H - mb, stroke: 'var(--mut)', 'stroke-width': 1, 'stroke-dasharray': '3 3', visibility: 'hidden' });
  const hd = el('circle', { r: 6.5, fill: 'none', stroke: 'var(--ink)', 'stroke-width': 2, visibility: 'hidden' });
  svg.appendChild(vl); svg.appendChild(hd);
  const ov = el('rect', { x: ml, y: 0, width: W - ml - mr, height: H, fill: 'transparent', style: 'cursor:crosshair' });
  svg.appendChild(ov);
  function at(ev) {
    const r = svg.getBoundingClientRect(), px = (ev.clientX - r.left) * (W / r.width);
    const i = Math.max(0, Math.min(NP - 1, Math.floor((px - ml) / step)));
    const isF = i >= NM, v = isF ? F.out[i - NM].f : y[i];
    vl.setAttribute('x1', X(i)); vl.setAttribute('x2', X(i)); vl.setAttribute('visibility', 'visible');
    hd.setAttribute('cx', X(i)); hd.setAttribute('cy', Y(v)); hd.setAttribute('visibility', 'visible');
    let h;
    if (isF) {
      const f = F.out[i - NM];
      h = `<b>${mLabel(i)} · previsão</b><br>${fm(v, met)}<div class="t2">80%: ${fm(f.lo80, met)} a ${fm(f.hi80, met)}<br>95%: ${fm(f.lo95, met)} a ${fm(f.hi95, met)}</div>`;
    } else {
      const d = R.month.dias[i];
      h = `<b>${mLabel(i)}</b><br>${METN[met]}: ${fm(v, met)}<div class="t2">${d} dias com vendas` + (d ? ` · ${fm(v / d, met)} por dia` : '') + '</div>';
    }
    showTip(h, ev.clientX, ev.clientY);
  }
  ov.addEventListener('pointermove', at); ov.addEventListener('pointerdown', at);
  ov.addEventListener('pointerleave', ev => { if (ev.pointerType === 'mouse') { hideTip(); vl.setAttribute('visibility', 'hidden'); hd.setAttribute('visibility', 'hidden'); } });
  host.innerHTML = ''; host.appendChild(svg);

  // texto
  const f = F.out;
  const verbo = { rev: 'faturar', ord: 'receber', piz: 'vender' }[met];
  const un = { rev: '', ord: ' pedidos', piz: ' pizzas' }[met];
  $('#insight').innerHTML = `<b>Previsão para ${mLabel(NM)} a ${mLabel(NM + 2)}:</b> a pizzaria deve ${verbo} cerca de <b>${fm(f[0].f, met)}${un}</b> por mês, com 95% de confiança entre ${fm(f[0].lo95, met)} e ${fm(f[0].hi95, met)}. O nível recente é estável, então a previsão segue reta.`;
  $('#hero-sub').textContent = `${METN[met]} por mês · ${mLabel(0)} a ${mLabel(NM - 1)}` + (st.per !== 0 ? ' (período filtrado em destaque)' : '');
  // tabela
  let t = `<tr><th>Mês</th><th>${METN[met]}</th><th>Dias com vendas</th></tr>`;
  y.forEach((v, i) => t += `<tr><td>${mLabel(i)}</td><td>${fm(v, met)}</td><td>${R.month.dias[i]}</td></tr>`);
  f.forEach((q, k) => t += `<tr class="f"><td>${mLabel(NM + k)} (previsão)</td><td>${fm(q.f, met)}</td><td>${fm(q.lo95, met)} a ${fm(q.hi95, met)}</td></tr>`);
  $('#tbl').innerHTML = t;
}

// ---------- gráficos de barras
function bars(host, items, o) {
  // items: {l, v, tip}; o: {horizontal, labelAll}
  const W = Math.max(host.clientWidth, 260), narrow = W < 460;
  const mx = Math.max(...items.map(i => i.v), 1), maxI = items.findIndex(i => i.v === mx);
  const svg = el('svg', { role: 'img', 'aria-label': o.aria });
  if (o.horizontal) {
    const rh = narrow ? 30 : 32, ml = Math.min(narrow ? 128 : 170, W * 0.42), mr = 64, H = items.length * rh + 4, bw = W - ml - mr;
    svg.setAttribute('viewBox', `0 0 ${W} ${H}`); svg.setAttribute('height', H);
    items.forEach((it, i) => {
      const yy = i * rh + 2, w = Math.max(2, it.v / mx * bw), g = el('g', { 'data-i': i, style: 'cursor:pointer' });
      g.appendChild(el('rect', { x: 0, y: yy, width: W, height: rh, fill: 'transparent' }));
      const maxc = Math.floor(ml / 7.2), lab = it.l.length > maxc ? it.l.slice(0, maxc - 1) + '…' : it.l;
      g.appendChild(el('text', { x: ml - 10, y: yy + rh / 2 + 4.5, 'text-anchor': 'end', 'font-size': 13, fill: 'var(--ink)' }, lab));
      g.appendChild(el('rect', { x: ml, y: yy + 6, width: w, height: rh - 12, rx: 4, fill: i === maxI ? 'var(--bar)' : 'var(--bar-dim)' }));
      g.appendChild(el('text', { x: ml + w + 8, y: yy + rh / 2 + 4.5, 'font-size': 12.5, fill: 'var(--mut)' }, o.fmt(it.v)));
      svg.appendChild(g);
    });
  } else {
    const H = narrow ? 230 : 270, ml = narrow ? 40 : 48, mr = 6, mt = 22, mb = 28, n = items.length, st_ = (W - ml - mr) / n, bw = Math.min(st_ * 0.68, 46);
    svg.setAttribute('viewBox', `0 0 ${W} ${H}`); svg.setAttribute('height', H);
    const ticks = niceTicks(0, mx * 1.05, 4), top = ticks[ticks.length - 1], Y = v => mt + (1 - v / top) * (H - mt - mb);
    ticks.forEach(t => {
      svg.appendChild(el('line', { x1: ml, x2: W - mr, y1: Y(t), y2: Y(t), stroke: 'var(--grid)' }));
      svg.appendChild(el('text', { x: ml - 7, y: Y(t) + 4, 'text-anchor': 'end', 'font-size': 12, fill: 'var(--mut)' }, o.axis(t)));
    });
    items.forEach((it, i) => {
      const cx = ml + (i + 0.5) * st_, y_ = Y(it.v), g = el('g', { 'data-i': i, style: 'cursor:pointer' });
      g.appendChild(el('rect', { x: cx - st_ / 2, y: mt, width: st_, height: H - mt - mb, fill: 'transparent' }));
      if (it.v > 0) g.appendChild(el('path', { d: `M${cx - bw / 2},${Y(0)} V${y_ + 4} Q${cx - bw / 2},${y_} ${cx - bw / 2 + 4},${y_} H${cx + bw / 2 - 4} Q${cx + bw / 2},${y_} ${cx + bw / 2},${y_ + 4} V${Y(0)} Z`, fill: i === maxI ? 'var(--bar)' : 'var(--bar-dim)' }));
      if (!(narrow && items.length > 10 && i % 2 === 1)) g.appendChild(el('text', { x: cx, y: H - 8, 'text-anchor': 'middle', 'font-size': items.length > 10 ? 11.5 : 12.5, fill: 'var(--mut)' }, it.l));
      if (i === maxI || (o.labelAll && !narrow)) g.appendChild(el('text', { x: cx, y: y_ - 6, 'text-anchor': 'middle', 'font-size': 12, 'font-weight': i === maxI ? 700 : 400, fill: 'var(--ink)' }, o.fmt(it.v)));
      svg.appendChild(g);
    });
  }
  const onMove = ev => {
    const g = ev.target.closest('g[data-i]'); if (!g) return;
    showTip(items[+g.dataset.i].tip, ev.clientX, ev.clientY);
  };
  svg.addEventListener('pointermove', onMove); svg.addEventListener('pointerdown', onMove);
  svg.addEventListener('pointerleave', ev => { if (ev.pointerType === 'mouse') hideTip(); });
  host.innerHTML = ''; host.appendChild(svg);
}

function renderBars(R) {
  const met = st.met, T = R.T;
  // dia da semana: média por dia com vendas
  const dowItems = R.dow.map((w, i) => {
    const v = w.dias ? w[met] / w.dias : 0;
    return { l: DIAS[i], v, tip: `<b>${DIAS_L[i]}</b><br>${fm(v, met)} por dia com vendas<div class="t2">${w.dias} dias com vendas · total ${fm(w[met], met)}</div>` };
  });
  bars($('#c-dow'), dowItems, { fmt: v => fm(v, met), axis: v => axisFmt(v, met), labelAll: true, aria: 'Média por dia com vendas, por dia da semana' });
  $('#dow-sub').textContent = `Média por dia com vendas · ${METN[met].toLowerCase()}`;
  // hora
  const hrs = []; for (let h = 10; h <= 23; h++) hrs.push(h);
  const tot = T[met] || 1;
  const hItems = hrs.map(h => ({ l: h === 10 ? '≤10h' : h + 'h', v: R.hr[h][met], tip: `<b>${h === 10 ? 'Até 10h59' : h + 'h às ' + h + 'h59'}</b><br>${fm(R.hr[h][met], met)}<div class="t2">${nf1.format(R.hr[h][met] / tot * 100)}% do total do período</div>` }));
  bars($('#c-hr'), hItems, { fmt: v => fm(v, met), axis: v => axisFmt(v, met), aria: 'Vendas por horário do dia' });
  $('#hr-sub').textContent = `Total no período · ${METN[met].toLowerCase()}`;
  // sabores
  const top = R.sk.map((s, i) => ({ i, v: s[met] })).reduce((acc, x) => { const k = SKN[x.i]; (acc[k] = acc[k] || { l: k, v: 0, rev: 0, piz: 0, ord: 0 }); acc[k].v += x.v; acc[k].rev += R.sk[x.i].rev; acc[k].piz += R.sk[x.i].piz; acc[k].ord += R.sk[x.i].ord; return acc; }, {});
  const sItems = Object.values(top).filter(s => s.v > 0).sort((a, b) => b.v - a.v).slice(0, 8).map(s => ({ l: s.l, v: s.v, tip: `<b>${s.l}</b><br>${money(s.rev)} · ${nf.format(s.piz)} pizzas<div class="t2">${nf.format(s.ord)} pedidos com este sabor</div>` }));
  bars($('#c-sab'), sItems, { horizontal: true, fmt: v => fm(v, met), aria: 'Oito sabores com mais vendas' });
  $('#sab-sub').textContent = `Top 8 · ${METN[met].toLowerCase()}`;
}

// ---------- ciclo
let raf = 0;
function update() { cancelAnimationFrame(raf); raf = requestAnimationFrame(draw); }
function draw() {
  hideTip();
  const R = compute(), per = PERIODOS[st.per];
  const d0 = new Date(base + per.from * 864e5), d1 = new Date(base + per.to * 864e5);
  const f = d => d.getUTCDate() + ' ' + MES[d.getUTCMonth()] + ' ' + d.getUTCFullYear();
  const fl = [];
  if (st.cat >= 0) fl.push(D.cat[st.cat]); if (st.tam >= 0) fl.push('tamanho ' + D.tam[st.tam]);
  $('#sub').textContent = `Painel de vendas · ${f(d0)} a ${f(d1)}` + (fl.length ? ' · ' + fl.join(', ') : '');
  renderKPIs(R); renderHero(R); renderBars(R);
}
['per', 'cat', 'tam', 'met'].forEach(buildChips);
draw();
let lastW = innerWidth;
addEventListener('resize', () => { if (innerWidth !== lastW) { lastW = innerWidth; update(); } });
document.addEventListener('pointerdown', e => { if (!e.target.closest('svg')) hideTip(); });
window.__vitto = { compute, ses, st };
})();
