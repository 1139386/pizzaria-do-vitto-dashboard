# Pizzaria do Vitto · Painel de vendas

Painel interativo (HTML, CSS e JavaScript puros, sem dependências) com filtros de período, categoria e tamanho, gráficos interativos e previsão de faturamento por série temporal.

## Publicar no GitHub Pages
1. Crie um repositório e envie estes arquivos para a branch `main`.
2. Em **Settings → Pages**, escolha **Deploy from a branch**, branch `main`, pasta `/ (root)`.
3. O endereço fica em `https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/`.

## Arquivos
- `index.html`, `style.css`, `app.js`: página, estilo e lógica.
- `data.js`: vendas de 01/01/2025 a 30/07/2026 (21.245 pedidos), já resumidas.
